## Module <om_account_accountant>

#### 04.05.2022
#### Version 14.0.8.1.0
##### IMP
- payment state

#### 11.03.2022
#### Version 14.0.8.0.0
##### IMP
- credit limit, recurring payments, daily reports and follow up dependency

#### Version 14.0.7.2.0
##### IMP
- moving excel report download link to accounting_pdf_reports module

#### 08.12.2021
#### Version 14.0.7.1.0
##### IMP
- reconciliation, payment method name and user group name updates

#### 08.12.2021
#### Version 14.0.7.0.0
##### IMP
- new menus

